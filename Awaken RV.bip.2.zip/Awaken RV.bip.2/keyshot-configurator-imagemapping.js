imagemappingdata =
[
    {
        "image": "Awaken RV.bip.2.1.png",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "20+49"
        ],
        "studio": 36870022
    },
    {
        "image": "Awaken RV.bip.2.2.png",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "20+200"
        ],
        "studio": 36870022
    },
    {
        "image": "Awaken RV.bip.2.3.png",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "20+49"
        ],
        "studio": 36870020
    },
    {
        "image": "Awaken RV.bip.2.4.png",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "20+200"
        ],
        "studio": 36870020
    },
    {
        "image": "Awaken RV.bip.2.5.png",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "20+49"
        ],
        "studio": 36870018
    },
    {
        "image": "Awaken RV.bip.2.6.png",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "20+200"
        ],
        "studio": 36870018
    },
    {
        "image": "Awaken RV.bip.2.7.png",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "20+49"
        ],
        "studio": 36870024
    },
    {
        "image": "Awaken RV.bip.2.8.png",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "20+200"
        ],
        "studio": 36870024
    }
];
